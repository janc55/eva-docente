<?php

namespace App\Filament\Docente\Resources\AsignacionResource\Pages;

use App\Filament\Docente\Resources\AsignacionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAsignacion extends CreateRecord
{
    protected static string $resource = AsignacionResource::class;
}
