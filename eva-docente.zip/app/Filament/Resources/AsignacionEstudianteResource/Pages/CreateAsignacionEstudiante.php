<?php

namespace App\Filament\Resources\AsignacionEstudianteResource\Pages;

use App\Filament\Resources\AsignacionEstudianteResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAsignacionEstudiante extends CreateRecord
{
    protected static string $resource = AsignacionEstudianteResource::class;
}
