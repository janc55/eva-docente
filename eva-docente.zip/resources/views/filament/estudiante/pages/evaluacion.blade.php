<x-filament-panels::page>
    <x-filament-panels::form>
        {{ $this->form }}
        <div>
            {{ $this->table }}
        </div>
    </x-filament-panels::form>
</x-filament-panels::page>
